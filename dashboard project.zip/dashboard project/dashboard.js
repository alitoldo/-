function uploadFile(sectionId) {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/pdf';
    input.onchange = e => {
        const file = e.target.files[0];
        if (file) {
            alert(`File ${file.name} uploaded to Section ${sectionId}`);
            // هنا يمكنك إضافة الكود لتخزين الملف في مجلد خاص
        }
    };
    input.click();
}

function printSection(sectionId) {
    const section = document.getElementById(`section${sectionId}`);
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`<html><body>${section.innerHTML}</body></html>`);
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
}
