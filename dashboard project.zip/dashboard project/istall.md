# Dashboard Project Installation

## متطلبات النظام
- متصفح ويب حديث (مثل Google Chrome أو Firefox)
- اتصال بالإنترنت (لتحميل مكتبة JsBarcode)

## خطوات التثبيت

1. **إنشاء مجلد المشروع**:
   - قم بإنشاء مجلد جديد على جهاز الكمبيوتر الخاص بك، وليكن اسمه `dashboard-project`.

2. **إنشاء الملفات**:
   - داخل المجلد، قم بإنشاء ثلاثة ملفات:
     - `index.html`
     - `style.css`
     - `dashboard.js`

3. **نسخ كود البرنامج**:
   - افتح كل ملف في محرر نصوص (مثل Notepad، Visual Studio Code، أو Sublime Text) ونسخ الكود التالي:

   - **index.html**:
     ```html
     <!DOCTYPE html>
     <html lang="en">
     <head>
         <meta charset="UTF-8">
         <meta http-equiv="X-UA-Compatible" content="IE=edge">
         <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <title>Dashboard</title>
         <link rel="stylesheet" href="style.css">
         <script src="https://cdnjs.cloudflare.com/ajax/libs/jsbarcode/3.11.0/JsBarcode.all.min.js"></script>
     </head>
     <body>
         <div class="dashboard">
             <header>
                 <h1>Welcome to the Engineering Department</h1>
                 <img src="logo.png" alt="Logo" class="logo">
             </header>
             <div class="sections">
                 <!-- 9 sections -->
                 <!-- Repeat sections as shown in the previous code -->
             </div>
         </div>
         <script src="dashboard.js"></script>
     </body>
     </html>
     ```

   - **style.css**:
     ```css
     html {
         height: 100%;
     }

     body {
         margin: 0;
         padding: 0;
         font-family: sans-serif;
         background: linear-gradient(#141e30, #243b55);
     }

     .dashboard {
         text-align: center;
         padding: 20px;
     }

     header {
         margin-bottom: 30px;
     }

     .logo {
         width: 150px;
     }

     .sections {
         display: flex;
         flex-wrap: wrap;
         justify-content: center;
         gap: 20px;
     }

     .section {
         background: rgba(0, 0, 0, 0.7);
         padding: 20px;
         border-radius: 10px;
         box-shadow: 0 15px 25px rgba(0, 0, 0, 0.6);
         width: 220px;
         transition: transform 0.3s;
     }

     .section:hover {
         transform: scale(1.05);
     }

     button {
         background-color: #39df18cb;
         border: none;
         color: white;
         padding: 10px 15px;
         text-align: center;
         text-transform: uppercase;
         margin: 10px 0;
         border-radius: 5px;
         cursor: pointer;
         position: relative;
         overflow: hidden;
         transition: color 0.4s;
     }

     button:hover {
         color: #03e9f4;
         background: transparent;
         box-shadow: 0 0 5px #03e9f4, 0 0 25px #03e9f4, 0 0 50px #03e9f4;
     }

     button:before {
         content: '';
         position: absolute;
         top: 50%;
         left: 50%;
         width: 300%;
         height: 300%;
         background: rgba(3, 233, 244, 0.5);
         border-radius: 50%;
         transition: transform 0.4s;
         transform: translate(-50%, -50%) scale(0);
         z-index: 0;
     }

     button:hover:before {
         transform: translate(-50%, -50%) scale(1);
     }

     button span {
         position: relative;
         z-index: 1;
     }
     ```

   - **dashboard.js**:
     ```javascript
     function uploadFile(sectionId) {
         const input = document.createElement('input');
         input.type = 'file';
         input.accept = 'application/pdf';
         input.onchange = e => {
             const file = e.target.files[0];
             if (file) {
                 alert(`File ${file.name} uploaded to Section ${sectionId}`);
             }
         };
         input.click();
     }

     function printSection(sectionId) {
         const barcodeId = `barcode${sectionId}`;
         const printWindow = window.open('', '_blank');
         printWindow.document.write(`
             <html>
                 <body>
                     <h2>Barcode for Section ${sectionId}</h2>
                     <svg id="${barcodeId}"></svg>
                     <script>
                         JsBarcode("#${barcodeId}", "${sectionId}", {format: "CODE128", lineColor: "#000", width: 4, height: 40});
                     </script>
                 </body>
             </html>
         `);
         printWindow.document.close();
         printWindow.print();
         printWindow.close();
     }

     // Add functions for sendFile, receiveFile, and forwardFile if needed
     ```

4. **فتح المشروع في المتصفح**:
   - افتح ملف `index.html` في متصفح الويب الخاص بك.

5. **اختبار الوظائف**:
   - تأكد من أن جميع الأزرار تعمل بشكل صحيح (مثل زر رفع الملف وزر الطباعة).

6. **إضافة شعار (اختياري)**:
   - إذا كنت ترغب في استخدام شعار، تأكد من إضافة صورة `logo.png` إلى المجلد الرئيسي.

## ملاحظات
- تأكد من وجود اتصال بالإنترنت عند تشغيل الصفحة لتحميل مكتبة JsBarcode.
